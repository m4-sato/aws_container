"""Merriam-Webster API toolkit."""
